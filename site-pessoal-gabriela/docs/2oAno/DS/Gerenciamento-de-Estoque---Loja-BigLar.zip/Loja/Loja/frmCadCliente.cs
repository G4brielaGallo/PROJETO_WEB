﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Loja
{
    public partial class frmCadCliente : Form
    {
        MySqlCommand comando;
        MySqlConnection conexao;
        MySqlDataReader data_reader;
        //MySqlDataAdapter data_adapter;
        string strSQL;

        public frmCadCliente()
        {
            InitializeComponent();
            conexao = new MySqlConnection("Server=localhost;Port=3306;Database=bd_MinhaEmpresa_TA;User=root"); // se tiver senha adiciona-se um Pwd='Senha'
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtRG_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && txtRG.Text != "")
            {
                try
                {
                    strSQL = "SELECT * FROM tb_Clientes WHERE RG_cli = @RG_cli"; //faz o select na tabela produtos de acordo com o código dele 
                    comando = new MySqlCommand(strSQL, conexao);
                    comando.Parameters.Clear();
                    comando.Parameters.AddWithValue("@RG_cli", txtRG.Text);
                    conexao.Open();
                    data_reader = comando.ExecuteReader();
                }
                catch (MySqlException Erro)
                {
                    MessageBox.Show("Erro ==>" + Erro.Message, "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Application.Exit();
                }
                finally
                {
                    if (!data_reader.HasRows) // não encontrou o código na tabela produtos
                    {
                        txtNome.ReadOnly = false; //libera txtDescricao para digitação
                        txtRG.ReadOnly = true;
                        txtRG.Enabled = false;
                        txtNome.Enabled = true;

                        txtNome.Focus();
                        toolStripStatusMensagem.Text = "Digite o nome do cliente";
                    }
                    else //Encontrou o código na tabela produtos
                    {
                        data_reader.Read();
                        txtNome.Text = Convert.ToString(data_reader["nome_cli"]);
                        txtEndereco.Text = Convert.ToString(data_reader["endereco_cli"]);
                        cmbUF.Text = Convert.ToString(data_reader["UF_cli"]);
                        txtTel.Text = Convert.ToString(data_reader["tel_cli"]);
                        txtCidade.Text = Convert.ToString(data_reader["cidade_cli"]);

                        toolStripStatusMensagem.Text = "Cliente já cadastrado";
                    }
                    conexao.Close();
                    comando = null;
                }
            }
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            try
            {
                strSQL = "Insert into tb_Clientes(RG_cli, nm_cli, endereco_cli, UF_cli, tel_cli, cidade_cli, ult_Atualizacao_cli) values (@parRG, @parNome, @parEndereco, @parUF, @parTel, @parCidade, CURRENT_TIMESTAMP)";
                comando = new MySqlCommand(strSQL, conexao);
                comando.Parameters.Clear();
                comando.Parameters.AddWithValue("@parRG", txtRG.Text);
                comando.Parameters.AddWithValue("@parNome", txtNome.Text);
                comando.Parameters.AddWithValue("@parEndereco", txtEndereco.Text);
                comando.Parameters.AddWithValue("@parUF", cmbUF.Text);
                comando.Parameters.AddWithValue("@parTel", txtTel.Text);
                comando.Parameters.AddWithValue("@parCidade", txtCidade.Text);
                conexao.Open();
                comando.ExecuteNonQuery();
            }
            catch (MySqlException Erro)
            {
                MessageBox.Show("ERRO => " + Erro.Message, "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }
            finally
            {
                toolStripStatusMensagem.Text = "Cadastro efetuado com sucesso!!!";
                conexao.Close();
                comando = null;
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtRG.ReadOnly = false;
            txtRG.Enabled = true;
            txtNome.ReadOnly = true;
            txtEndereco.ReadOnly = true;
            cmbUF.Enabled = false;
            txtTel.ReadOnly = true;
            txtCidade.ReadOnly = true;
            btnCadastrar.Enabled = false;

            txtRG.Clear();
            txtNome.Clear();
            cmbUF.SelectedIndex = -1;
            txtEndereco.Clear();
            txtTel.Clear();
            txtCidade.Clear();
            toolStripStatusMensagem.Text = "Informe o RG do cliente";
        }

        private void txtNome_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && txtNome.Text != "")
            {
                toolStripStatusMensagem.Text = "Digite o Telefone";
                txtTel.Enabled = true;
                txtTel.ReadOnly = false;
                txtNome.ReadOnly = true;
                txtNome.Enabled = false;
                txtTel.Focus();
            }
        }

        private void txtTel_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && txtTel.Text != "")
            {
                toolStripStatusMensagem.Text = "Digite o Endereço";
                txtEndereco.ReadOnly = false;
                txtEndereco.Enabled = true;
                txtTel.ReadOnly = true;
                txtTel.Enabled = false;
                txtEndereco.Focus();
            }
        }

        private void txtEndereco_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && txtEndereco.Text != "")
            {
                toolStripStatusMensagem.Text = "Digite a Cidade";
                txtCidade.ReadOnly = false;
                txtCidade.Enabled = true;
                txtEndereco.ReadOnly = true;
                txtEndereco.Enabled = false;
                txtCidade.Focus();
            }
        }

        private void txtCidade_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                toolStripStatusMensagem.Text = "Selecione a UF";
                txtCidade.ReadOnly = true;
                txtCidade.Enabled = false;
                cmbUF.Enabled = true;
                cmbUF.Focus();
            }
        }

        private void cmbUF_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (cmbUF.Text == "")
                {
                    MessageBox.Show("Selecione um valor", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    toolStripStatusMensagem.Text = "Botão Liberado!!!";
                    btnCadastrar.Enabled = true;
                    cmbUF.Enabled = false;
                    btnCadastrar.Focus();
                }
            }
        }

        private void frmCadCliente_Activated(object sender, EventArgs e)
        {
            txtRG.Focus();
        }

        private void txtTel_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar))  //8=backspace,44=virgula,45=Negativo
            {
                e.Handled = true;
            }
        }
    }
}
