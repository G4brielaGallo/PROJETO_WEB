﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Loja
{
    public partial class frmDelProd : Form
    {
        MySqlCommand comando;
        MySqlConnection conexao;
        MySqlDataReader data_reader;
        //MySqlDataAdapter data_adapter;
        string strSQL;
        decimal vPrcCusto = 0, vMarg_Lucro = 0, vPrcVenda = 0, vEstoq_Min = 0, vQtd_Estoq = 0;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtCodigo.ReadOnly = false;
            txtCodigo.Enabled = true;
            txtDescricao.ReadOnly = true;
            txtQtd_Estoq.ReadOnly = true;
            cmbUnidade.Enabled = false;
            txtLocacao.ReadOnly = true;
            txtPrcCusto.ReadOnly = true;
            txtMarg_Lucro.ReadOnly = true;
            txtEstoq_Min.ReadOnly = true;
            btnDeletar.Enabled = false;

            txtCodigo.Clear();
            txtDescricao.Clear();
            txtQtd_Estoq.Clear();
            cmbUnidade.SelectedIndex = -1;
            txtLocacao.Clear();
            txtPrcCusto.Clear();
            txtMarg_Lucro.Clear();
            txtEstoq_Min.Clear();
            txtPrcVenda.Text = "0,00";
            toolStripStatusMensagem.Text = "Informe o código do produto";
        }

        private void btnDeletar_Click(object sender, EventArgs e)
        {
            try
            {
                strSQL = "Delete from tb_Produtos where cd_prod = @parCodigo";
                comando = new MySqlCommand(strSQL, conexao);
                comando.Parameters.Clear();
                comando.Parameters.AddWithValue("@parCodigo", txtCodigo.Text);
                conexao.Open();
                comando.ExecuteNonQuery();
            }
            catch (MySqlException Erro)
            {
                MessageBox.Show("ERRO => " + Erro.Message, "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }
            finally
            {
                toolStripStatusMensagem.Text = "Deletado com sucesso!!!";
                conexao.Close();
                comando = null;
            }
        }

        private void txtCodigo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && txtCodigo.Text != "")
            {
                try
                {
                    strSQL = "select * from tb_Produtos where cd_prod = @parCodigo";
                    comando = new MySqlCommand(strSQL, conexao);
                    comando.Parameters.Clear();
                    comando.Parameters.AddWithValue("@parCodigo", txtCodigo.Text);
                    conexao.Open();
                    data_reader = comando.ExecuteReader(); // comando.ExecuteScalar para apenas 1 dado, reader para mais de 1 dado

                }
                catch (MySqlException Erro)
                {
                    MessageBox.Show("ERRO => " + Erro.Message, "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Application.Exit();
                }
                finally
                {
                    if (!data_reader.HasRows)
                    {
                        toolStripStatusMensagem.Text = "Codigo inexistente!";
                    }
                    else
                    {
                        while (data_reader.Read())
                        {
                            txtDescricao.Text = Convert.ToString(data_reader["descricao_prod"]);
                            txtQtd_Estoq.Text = Convert.ToString(data_reader["qtd_Estoq_prod"]);
                            cmbUnidade.Text = Convert.ToString(data_reader["unidade_prod"]);
                            txtLocacao.Text = Convert.ToString(data_reader["locacao_prod"]);
                            txtEstoq_Min.Text = Convert.ToString(data_reader["Estoq_Min_prod"]);
                            txtPrcCusto.Text = Convert.ToString(data_reader["PrcCusto_prod"]);
                            txtMarg_Lucro.Text = Convert.ToString(data_reader["Marg_Lucro_prod"]);

                            vPrcCusto = Decimal.Parse(txtPrcCusto.Text);
                            vMarg_Lucro = Decimal.Parse(txtMarg_Lucro.Text);
                            vPrcVenda = (vPrcCusto * (vMarg_Lucro / 100)) + vPrcCusto;
                            txtPrcVenda.Text = vPrcVenda.ToString("C");
                        }
                        toolStripStatusMensagem.Text = "Produto Encontrado";
                        btnDeletar.Enabled = true;
                    }

                    conexao.Close();
                    comando = null;
                }
            }
        }

        public frmDelProd()
        {
            InitializeComponent();
            conexao = new MySqlConnection("Server=localhost;Port=3306;Database=bd_MinhaEmpresa_TA;User=root"); // se tiver senha adiciona-se um Pwd='Senha'
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void frmDelProd_Activated(object sender, EventArgs e)
        {
            txtCodigo.Focus();
        }
    }
}
