﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Loja
{
    public partial class frmAltCliente : Form
    {
        MySqlCommand comando;
        MySqlConnection conexao;
        MySqlDataReader data_reader;
        //MySqlDataAdapter data_adapter;
        string strSQL;

        public frmAltCliente()
        {
            InitializeComponent();
            conexao = new MySqlConnection("Server=localhost;Port=3306;Database=bd_MinhaEmpresa_TA;User=root"); // se tiver senha adiciona-se um Pwd='Senha'
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            try
            {
                strSQL = "Update tb_Clientes set nm_cli = @parNome, endereco_cli = @parEndereco, UF_cli = @parUF, tel_cli = @parTel, cidade_cli = @parCidade, ult_Atualizacao_cli = CURRENT_TIMESTAMP where RG_cli = @parRG";
                comando = new MySqlCommand(strSQL, conexao);
                comando.Parameters.Clear();
                comando.Parameters.AddWithValue("@parRG", txtRG.Text);
                comando.Parameters.AddWithValue("@parNome", txtNome.Text);
                comando.Parameters.AddWithValue("@parEndereco", txtEndereco.Text);
                comando.Parameters.AddWithValue("@parUF", cmbUF.Text);
                comando.Parameters.AddWithValue("@parTel", txtTel.Text);
                comando.Parameters.AddWithValue("@parCidade", txtCidade.Text);
                conexao.Open();
                comando.ExecuteNonQuery();
            }
            catch (MySqlException Erro)
            {
                MessageBox.Show("ERRO => " + Erro.Message, "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }
            finally
            {
                toolStripStatusMensagem.Text = "Alteração realizada com sucesso!!!";
                conexao.Close();
                comando = null;
            }
        }

        private void txtRG_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && txtRG.Text != "")
            {
                try
                {
                    strSQL = "select * from tb_Clientes where RG_cli = @parRG";
                    comando = new MySqlCommand(strSQL, conexao);
                    comando.Parameters.Clear();
                    comando.Parameters.AddWithValue("@parRG", txtRG.Text);
                    conexao.Open();
                    data_reader = comando.ExecuteReader(); // comando.ExecuteScalar para apenas 1 dado, reader para mais de 1 dado

                }
                catch (MySqlException Erro)
                {
                    MessageBox.Show("ERRO => " + Erro.Message, "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Application.Exit();
                }
                finally
                {
                    if (data_reader.HasRows)
                    {
                        while (data_reader.Read())
                        {
                            txtNome.Text = Convert.ToString(data_reader["nm_cli"]);
                            txtEndereco.Text = Convert.ToString(data_reader["endereco_cli"]);
                            cmbUF.Text = Convert.ToString(data_reader["UF_cli"]);
                            txtTel.Text = Convert.ToString(data_reader["tel_cli"]);
                            txtCidade.Text = Convert.ToString(data_reader["cidade_cli"]);
                        }
                        toolStripStatusMensagem.Text = "Altere o que deseja no Produto " + txtRG.Text;
                        txtNome.Enabled = true;
                        txtNome.ReadOnly = false;
                        txtNome.Focus();
                        txtRG.ReadOnly = true;
                        txtRG.Enabled = false;
                        txtTel.Enabled = true;
                        txtTel.ReadOnly = false;
                        txtEndereco.Enabled = true;
                        txtEndereco.ReadOnly = false;
                        cmbUF.Enabled = true;
                        txtCidade.Enabled = true;
                        txtCidade.ReadOnly = false;
                    }
                    else
                    {
                        // Se não tiver o codigo na tabela produtos

                        toolStripStatusMensagem.Text = "RG Inexistente";
                    }

                    conexao.Close();
                    comando = null;
                }
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtRG.ReadOnly = false;
            txtRG.Enabled = true;
            txtNome.ReadOnly = true;
            txtEndereco.ReadOnly = true;
            cmbUF.Enabled = false;
            txtTel.ReadOnly = true;
            txtCidade.ReadOnly = true;
            btnAlterar.Enabled = false;

            txtRG.Clear();
            txtNome.Clear();
            cmbUF.SelectedIndex = -1;
            txtEndereco.Clear();
            txtTel.Clear();
            txtCidade.Clear();
            toolStripStatusMensagem.Text = "Informe o RG do cliente";
        }

        private void frmAltCliente_Activated(object sender, EventArgs e)
        {
            txtRG.Focus();
        }

        private void txtTel_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar))  //8=backspace,44=virgula,45=Negativo
            {
                e.Handled = true;
            }
        }
    }
}
