﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Loja
{
    public partial class frmAltProd : Form
    {
        MySqlCommand comando;
        MySqlConnection conexao;
        MySqlDataReader data_reader;
        //MySqlDataAdapter data_adapter;
        string strSQL;
        decimal vPrcCusto = 0, vMarg_Lucro = 0, vPrcVenda = 0, vEstoq_Min = 0, vQtd_Estoq = 0;

        private void txtDescricao_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && txtDescricao.Text != "")
            {
                txtQtd_Estoq.Enabled = true;
                toolStripStatusMensagem.Text = "Alterar a quantidade no estoque apenas na entrada e saida";
                txtDescricao.ReadOnly = true;
                txtDescricao.Enabled = false;
                txtQtd_Estoq.Focus();
            }
        }

        private void txtQtd_Estoq_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                toolStripStatusMensagem.Text = "Selecione a unidade";
                txtQtd_Estoq.ReadOnly = true;
                txtQtd_Estoq.Enabled = false;
                cmbUnidade.Enabled = true;
                cmbUnidade.Focus();
            }
        }

        private void cmbUnidade_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (cmbUnidade.Text == "")
                {
                    MessageBox.Show("Selecione um valor", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    toolStripStatusMensagem.Text = "Digite a locação do produto";
                    txtLocacao.ReadOnly = false;
                    txtLocacao.Enabled = true;
                    cmbUnidade.Enabled = false;
                    txtLocacao.Focus();
                }
            }
        }


        private void txtLocacao_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && txtLocacao.Text != "")
            {
                toolStripStatusMensagem.Text = "Digite o Estoque Minimo";
                txtEstoq_Min.ReadOnly = false;
                txtEstoq_Min.Enabled = true;
                txtLocacao.ReadOnly = true;
                txtLocacao.Enabled = false;
                txtEstoq_Min.Focus();
            }
        }

        private void txtEstoq_Min_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && txtEstoq_Min.Text != "")
            {
                toolStripStatusMensagem.Text = "Digite o Preço de custo";
                txtEstoq_Min.ReadOnly = true;
                txtEstoq_Min.Enabled = false;
                txtPrcCusto.ReadOnly = false;
                txtPrcCusto.Enabled = true;
                txtPrcCusto.Focus();
            }
        }

        private void txtPrcCusto_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && txtPrcCusto.Text != "")
            {
                toolStripStatusMensagem.Text = "Digite a margem de lucro";
                txtPrcCusto.ReadOnly = true;
                txtPrcCusto.Enabled = false;
                txtMarg_Lucro.ReadOnly = false;
                txtMarg_Lucro.Enabled = true;
                txtMarg_Lucro.Focus();
            }
        }

        private void txtMarg_Lucro_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && txtMarg_Lucro.Text != "")
            {
                vPrcCusto = Decimal.Parse(txtPrcCusto.Text);
                vMarg_Lucro = Decimal.Parse(txtMarg_Lucro.Text);

                vPrcVenda = (vPrcCusto * (vMarg_Lucro / 100)) + vPrcCusto;
                txtPrcVenda.Text = String.Format("{0:C2}", vPrcVenda); // Moeda com 2 casas decimais

                btnAlterar.Enabled = true;
                txtMarg_Lucro.ReadOnly = false;
                txtMarg_Lucro.Enabled = false;
                btnAlterar.Focus();
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            try
            {
                strSQL = "Update tb_Produtos set descricao_prod = @parDescricao, qtd_Estoq_prod = @parQtdEstoq, Estoq_Min_prod = @parEstoqMin, unidade_prod = @parUnidade, locacao_prod = @parLocacao, PrcCusto_prod = @parPrcCusto, Marg_Lucro_prod = @parMargLucro, ult_Atualizacao_prod = CURRENT_TIMESTAMP where cd_prod = @parCodigo";
                comando = new MySqlCommand(strSQL, conexao);
                comando.Parameters.Clear();
                comando.Parameters.AddWithValue("@parCodigo", txtCodigo.Text);
                comando.Parameters.AddWithValue("@parDescricao", txtDescricao.Text);
                comando.Parameters.AddWithValue("@parQtdEstoq", txtQtd_Estoq.Text);
                comando.Parameters.AddWithValue("@parEstoqMin", txtEstoq_Min.Text);
                comando.Parameters.AddWithValue("@parUnidade", cmbUnidade.Text);
                comando.Parameters.AddWithValue("@parLocacao", txtLocacao.Text);
                comando.Parameters.AddWithValue("@parPrcCusto", txtPrcCusto.Text);
                comando.Parameters.AddWithValue("@parMargLucro", txtMarg_Lucro.Text);
                conexao.Open();
                comando.ExecuteNonQuery();
            }
            catch (MySqlException Erro)
            {
                MessageBox.Show("ERRO => " + Erro.Message, "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }
            finally
            {
                toolStripStatusMensagem.Text = "Alteração realizada com sucesso!!!";
                conexao.Close();
                comando = null;
            }
        }

        private void txtCodigo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && txtCodigo.Text != "")
            {
                try
                {
                    strSQL = "select * from tb_Produtos where cd_prod = @parCodigo";
                    comando = new MySqlCommand(strSQL, conexao);
                    comando.Parameters.Clear();
                    comando.Parameters.AddWithValue("@parCodigo", txtCodigo.Text);
                    conexao.Open();
                    data_reader = comando.ExecuteReader(); // comando.ExecuteScalar para apenas 1 dado, reader para mais de 1 dado

                }
                catch (MySqlException Erro)
                {
                    MessageBox.Show("ERRO => " + Erro.Message, "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Application.Exit();
                }
                finally
                {
                    if (data_reader.HasRows)
                    {
                        while (data_reader.Read())
                        {
                            txtDescricao.Text = Convert.ToString(data_reader["descricao_prod"]);
                            txtQtd_Estoq.Text = Convert.ToString(data_reader["qtd_Estoq_prod"]);
                            cmbUnidade.Text = Convert.ToString(data_reader["unidade_prod"]);
                            txtLocacao.Text = Convert.ToString(data_reader["locacao_prod"]);
                            txtEstoq_Min.Text = Convert.ToString(data_reader["Estoq_Min_prod"]);
                            txtPrcCusto.Text = Convert.ToString(data_reader["PrcCusto_prod"]);
                            txtMarg_Lucro.Text = Convert.ToString(data_reader["Marg_Lucro_prod"]);

                            vPrcCusto = Decimal.Parse(txtPrcCusto.Text);
                            vMarg_Lucro = Decimal.Parse(txtMarg_Lucro.Text);
                            vPrcVenda = (vPrcCusto * (vMarg_Lucro / 100)) + vPrcCusto;
                            txtPrcVenda.Text = vPrcVenda.ToString("C");
                        }
                        toolStripStatusMensagem.Text = "Altere o que deseja no Produto " + txtCodigo.Text;
                        txtDescricao.Enabled = true;
                        txtDescricao.ReadOnly = false;
                        txtDescricao.Focus();
                        txtCodigo.ReadOnly = true;
                        txtCodigo.Enabled = false;
                    }
                    else
                    {
                        // Se não tiver o codigo na tabela produtos

                        toolStripStatusMensagem.Text = "Codigo Inexistente";
                    }

                    conexao.Close();
                    comando = null;
                }
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtCodigo.ReadOnly = false;
            txtCodigo.Enabled = true;
            txtDescricao.ReadOnly = true;
            txtQtd_Estoq.ReadOnly = true;
            cmbUnidade.Enabled = false;
            txtLocacao.ReadOnly = true;
            txtPrcCusto.ReadOnly = true;
            txtMarg_Lucro.ReadOnly = true;
            txtEstoq_Min.ReadOnly = true;
            btnAlterar.Enabled = false;

            txtCodigo.Clear();
            txtDescricao.Clear();
            txtQtd_Estoq.Text = "0";
            cmbUnidade.SelectedIndex = -1;
            txtLocacao.Clear();
            txtPrcCusto.Clear();
            txtMarg_Lucro.Clear();
            txtEstoq_Min.Clear();
            txtPrcVenda.Text = "0,00";
            toolStripStatusMensagem.Text = "Informe o código do produto";
        }

        public frmAltProd()
        {
            InitializeComponent();
            conexao = new MySqlConnection("Server=localhost;Port=3306;Database=bd_MinhaEmpresa_TA;User=root"); // se tiver senha adiciona-se um Pwd='Senha'
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void frmAltProd_Activated(object sender, EventArgs e)
        {
            txtCodigo.Focus();
        }
    }
}
