﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO; // Para acessar arquivos (utilizado para bntImportar funcionar)
using MySql.Data.MySqlClient; // Inserir no codigo para conectar o banco de dados

namespace Loja
{
    public partial class frmCadNovoUsuario : Form
    {
        // Variáveis de conexão de controle

        MySqlConnection conexao;
        MySqlCommand comando;
        MySqlDataAdapter da;
        MySqlDataReader dr;
        string strSQL;

        public frmCadNovoUsuario()
        {
            InitializeComponent();

            conexao = new MySqlConnection("Server=localhost;Port=3306;Database=bd_MinhaEmpresa_TA;User=root"); // se tiver senha adiciona-se um Pwd='Senha'
        }

        private void txtUsuario_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void frmCadNovoUsuario_Load(object sender, EventArgs e)
        {
            txtUsuario.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
            this.Visible = false;
            frmLogin FLogin = new frmLogin();
            FLogin.Show();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Visible = false;

            frmLogin FLogin = new frmLogin();
            FLogin.Show();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            try
            {
                strSQL = "INSERT INTO tb_login (usuario_log, senha_log, nm_log, ult_Atualizacao_log) values(@par_Usuario, @par_Senha, @par_Nome, CURRENT_TIMESTAMP)";

                comando = new MySqlCommand(strSQL, conexao);
                comando.Parameters.Clear();
                comando.Parameters.AddWithValue("@par_Usuario", txtUsuario.Text);
                comando.Parameters.AddWithValue("@par_Senha", txtSenha.Text);
                comando.Parameters.AddWithValue("@par_Nome", txtNome.Text);
                conexao.Open();
                comando.ExecuteNonQuery();

                MessageBox.Show("Usuário cadastrado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            catch (MySqlException Erro)
            {
                MessageBox.Show("Erro ==>" + Erro.Message, "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }

            finally
            {
                this.Visible = false;
                frmLogin frmLog = new frmLogin();
                frmLog.Show();

                conexao.Close();
                comando = null;
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNome.ReadOnly = true;
            txtSenha.ReadOnly = true;
            txtUsuario.ReadOnly = false;
            btnCadastrar.Enabled = false;

            txtNome.Clear();
            txtSenha.Clear();
            txtUsuario.Clear();
            txtUsuario.Focus();
        }

        private void txtUsuario_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                txtUsuario.ReadOnly = true;
            txtSenha.ReadOnly = true;
            {
                try
                {
                    strSQL = "SELECT * FROM tb_Login WHERE usuario_log = @par_Usuario";
                    comando = new MySqlCommand(strSQL, conexao);
                    comando.Parameters.Clear();
                    comando.Parameters.AddWithValue("@par_Usuario", txtUsuario.Text);
                    conexao.Open();
                    dr = comando.ExecuteReader();
                }

                catch (MySqlException Erro)
                {
                    MessageBox.Show("Erro ==>" + Erro.Message, "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Application.Exit();
                }

                finally
                {
                    if (!dr.HasRows)
                    {
                        txtNome.ReadOnly = false;
                        txtSenha.ReadOnly = false;
                        btnCadastrar.Enabled = true;
                        txtNome.Clear();
                        txtSenha.Clear();
                        txtUsuario.Focus();
                    }
                    else
                    {
                        dr.Read();
                        txtNome.Text = Convert.ToString(dr["nm_log"]);
                        txtSenha.Text = Convert.ToString(dr["senha_log"]);
                    }
                    conexao.Close();
                    comando = null;
                }
            }
        }
    }
}
