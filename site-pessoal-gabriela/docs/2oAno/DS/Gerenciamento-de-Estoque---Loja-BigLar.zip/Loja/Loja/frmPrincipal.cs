﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Loja
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void cadastrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCadProd objCadProd = new frmCadProd();
            objCadProd.MdiParent = this; //código que declara que esta tela é filha do form principal
            objCadProd.Show();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void alterarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAltProd objAltProd = new frmAltProd();
            objAltProd.MdiParent = this;
            objAltProd.Show();
        }

        private void excluirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmDelProd objDelProd = new frmDelProd();
            objDelProd.MdiParent = this;
            objDelProd.Show();
        }

        private void cadastrarToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmCadCliente objCadCliente = new frmCadCliente();
            objCadCliente.MdiParent = this;
            objCadCliente.Show();
        }

        private void alterarToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmAltCliente objAltCliente = new frmAltCliente();
            objAltCliente.MdiParent = this;
            objAltCliente.Show();
        }

        private void excluirToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmDelClientes objDelCliente = new frmDelClientes();
            objDelCliente.MdiParent = this;
            objDelCliente.Show();
        }
    }
}
