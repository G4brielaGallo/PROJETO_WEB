﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient; // Inserir no codigo para conectar o banco de dados

namespace Loja
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();

            conexao = new MySqlConnection("Server=localhost;Port=3306;Database=bd_MinhaEmpresa_TA;User=root");
        }

        // Variáveis de conexão de controle

        MySqlConnection conexao;
        MySqlCommand comando;
        MySqlDataAdapter da;
        MySqlDataReader dr;
        string strSQL;

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            try
            {
                strSQL = "SELECT senha_log FROM tb_Login WHERE usuario_log = @par_Usuario";
                comando = new MySqlCommand(strSQL, conexao);
                comando.Parameters.Clear();
                comando.Parameters.AddWithValue("@par_Usuario", txtUsuario.Text);
                conexao.Open();
                comando.ExecuteScalar();
            }

            catch (MySqlException Erro)
            {
                MessageBox.Show("Erro ==>" + Erro.Message, "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }
            finally
            {
                if (comando.ExecuteScalar() == null) //Não achou o usuário
                {
                    MessageBox.Show("Usuário não cadastrado", "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    conexao.Close();
                    comando = null;
                }

                else
                {
                    if (Convert.ToString(comando.ExecuteScalar()) != txtSenha.Text)
                    {
                        MessageBox.Show("Senha inválida", "Messagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtSenha.Focus();
                        conexao.Close();
                        comando = null;
                    }

                    else
                    {
                        this.Visible = false;
                        frmPrincipal frmPrinc = new frmPrincipal();
                        frmPrinc.Show();

                        conexao.Close();
                        comando = null;
                    }
                }
            }

            if (txtUsuario.Text.Trim() == "")
            {
                MessageBox.Show("Insira um usuário!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtUsuario.Focus();
                return;
            }

            if (txtSenha.Text.Trim() == "")
            {
                MessageBox.Show("Insira uma senha!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtSenha.Focus();
                return;
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void frmLogin_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Confirma a saída da aplicação ?",
            "Sair", MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                e.Cancel = false;
            }
            else
            {
                e.Cancel = true;
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Visible = false;

            frmCadNovoUsuario FCadastrar = new frmCadNovoUsuario();
            FCadastrar.Show();
        }

        private void frmLogin_Activated(object sender, EventArgs e)
        {
            txtUsuario.Focus();
        }
    }
}
