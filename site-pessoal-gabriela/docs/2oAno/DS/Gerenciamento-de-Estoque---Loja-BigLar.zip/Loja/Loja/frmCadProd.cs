﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Loja
{
    public partial class frmCadProd : Form
    {
        MySqlCommand comando;
        MySqlConnection conexao;
        MySqlDataReader data_reader;
        //MySqlDataAdapter data_adapter;
        string strSQL;
        decimal vPrcCusto = 0, vMarg_Lucro = 0, vPrcVenda = 0, vEstoq_Min = 0, vQtd_Estoq = 0;

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtDescricao_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && txtDescricao.Text != "")
            {
                txtQtd_Estoq.Enabled = true;
                toolStripStatusMensagem.Text = "Alterar a quantidade no estoque apenas na entrada e saida";
                txtDescricao.ReadOnly = true;
                txtDescricao.Enabled = false;
                txtQtd_Estoq.Focus();
            }
        }

        private void txtQtd_Estoq_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                toolStripStatusMensagem.Text = "Selecione a unidade";
                txtQtd_Estoq.ReadOnly = true;
                txtQtd_Estoq.Enabled = false;
                cmbUnidade.Enabled = true;
                cmbUnidade.Focus();
            }
        }

        private void cmbUnidade_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (cmbUnidade.Text == "")
                {
                    MessageBox.Show("Selecione um valor", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    toolStripStatusMensagem.Text = "Digite a locação do produto";
                    txtLocacao.ReadOnly = false;
                    txtLocacao.Enabled = true;
                    cmbUnidade.Enabled = false;
                    txtLocacao.Focus();
                }
            }
        }

        private void txtLocacao_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && txtLocacao.Text != "")
            {
                toolStripStatusMensagem.Text = "Digite o Estoque Minimo";
                txtEstoq_Min.ReadOnly = false;
                txtEstoq_Min.Enabled = true;
                txtLocacao.ReadOnly = true;
                txtLocacao.Enabled = false;
                txtEstoq_Min.Focus();
            }
        }

        private void txtEstoq_Min_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && txtEstoq_Min.Text != "")
            {
                toolStripStatusMensagem.Text = "Digite o Preço de custo";
                txtEstoq_Min.ReadOnly = true;
                txtEstoq_Min.Enabled = false;
                txtPrcCusto.ReadOnly = false;
                txtPrcCusto.Enabled = true;
                txtPrcCusto.Focus();
            }
        }

        private void txtPrcCusto_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && txtPrcCusto.Text != "")
            {
                toolStripStatusMensagem.Text = "Digite a margem de lucro";
                txtPrcCusto.ReadOnly = true;
                txtPrcCusto.Enabled = false;
                txtMarg_Lucro.ReadOnly = false;
                txtMarg_Lucro.Enabled = true;
                txtMarg_Lucro.Focus();
            }
        }

        private void txtMarg_Lucro_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && txtMarg_Lucro.Text != "")
            {
                vPrcCusto = Decimal.Parse(txtPrcCusto.Text);
                vMarg_Lucro = Decimal.Parse(txtMarg_Lucro.Text);

                vPrcVenda = (vPrcCusto * (vMarg_Lucro / 100)) + vPrcCusto;
                txtPrcVenda.Text = String.Format("{0:C2}", vPrcVenda); // Moeda com 2 casas decimais

                btnCadastar.Enabled = true;
                txtMarg_Lucro.ReadOnly = false;
                txtMarg_Lucro.Enabled = false;
                btnCadastar.Focus();
                toolStripStatusMensagem.Text = "Clique no botão para cadastrar";
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtCodigo.ReadOnly = false;
            txtCodigo.Enabled = true;
            txtDescricao.ReadOnly = true;
            txtQtd_Estoq.ReadOnly = true;
            cmbUnidade.Enabled = false;
            txtLocacao.ReadOnly = true;
            txtPrcCusto.ReadOnly = true;
            txtMarg_Lucro.ReadOnly = true;
            txtEstoq_Min.ReadOnly = true;
            btnCadastar.Enabled = false;

            txtCodigo.Clear();
            txtDescricao.Clear();
            txtQtd_Estoq.Text = "0";
            cmbUnidade.SelectedIndex = -1;
            txtLocacao.Clear();
            txtPrcCusto.Clear();
            txtMarg_Lucro.Clear();
            txtEstoq_Min.Clear();
            txtPrcVenda.Text = "0,00";
            toolStripStatusMensagem.Text = "Informe o código do produto";
        }

        public frmCadProd()
        {
            InitializeComponent();
            conexao = new MySqlConnection("Server=localhost;Port=3306;Database=bd_MinhaEmpresa_TA;User=root"); // se tiver senha adiciona-se um Pwd='Senha'
        }

        private void txtCodigo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && txtCodigo.Text != "")
            {
                try
                {
                    strSQL = "SELECT * FROM tb_Produtos WHERE cd_prod = @cd_prod"; //faz o select na tabela produtos de acordo com o código dele 
                    comando = new MySqlCommand(strSQL, conexao);
                    comando.Parameters.Clear();
                    comando.Parameters.AddWithValue("@cd_prod", txtCodigo.Text);
                    conexao.Open();
                    data_reader = comando.ExecuteReader();
                }
                catch (MySqlException Erro)
                {
                    MessageBox.Show("Erro ==>" + Erro.Message, "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Application.Exit();
                }
                finally
                {
                    if (!data_reader.HasRows) // não encontrou o código na tabela produtos
                    {
                        txtDescricao.ReadOnly = false; //libera txtDescricao para digitação
                        txtCodigo.ReadOnly = true;
                        txtCodigo.Enabled = false;
                        txtDescricao.Enabled = true;

                        txtDescricao.Focus();
                        toolStripStatusMensagem.Text = "Digite a descrição do produto";
                    }
                    else //Encontrou o código na tabela produtos
                    {
                        data_reader.Read();
                        txtDescricao.Text = Convert.ToString(data_reader["prod_Descricao"]);
                        txtQtd_Estoq.Text = Convert.ToString(data_reader["prod_Qtd_Estoq"]);
                        cmbUnidade.Text = Convert.ToString(data_reader["prod_Unidade"]);
                        txtLocacao.Text = Convert.ToString(data_reader["prod_Locacao"]);
                        txtEstoq_Min.Text = Convert.ToString(data_reader["prod_Estoq_Min"]);
                        txtPrcCusto.Text = Convert.ToString(data_reader["prod_PrcCusto"]);
                        txtMarg_Lucro.Text = Convert.ToString(data_reader["prod_Marg_Lucro"]);

                        vPrcCusto = decimal.Parse(txtPrcCusto.Text);
                        vMarg_Lucro = decimal.Parse(txtMarg_Lucro.Text);
                        vPrcVenda = (vPrcCusto * (vMarg_Lucro / 100)) + vPrcCusto;
                        txtPrcVenda.Text = vPrcVenda.ToString("C");
                        toolStripStatusMensagem.Text = "Produto já cadastrado";
                    }
                    conexao.Close();
                    comando = null;
                }
            }
        }

        private void btnCadastar_Click(object sender, EventArgs e)
        {
            try
            {
                strSQL = "Insert into tb_Produtos(cd_prod, descricao_prod, qtd_Estoq_prod, Estoq_Min_prod, unidade_prod, locacao_prod, PrcCusto_prod, Marg_Lucro_prod, ult_Atualizacao_prod) values (@parCodigo, @parDescricao, @parQtdEstoq, @parEstoqMin, @parUnidade, @parLocacao, @parPrcCusto, @parMargLucro, CURRENT_TIMESTAMP)";
                comando = new MySqlCommand(strSQL, conexao);
                comando.Parameters.Clear();
                comando.Parameters.AddWithValue("@parCodigo", txtCodigo.Text);
                comando.Parameters.AddWithValue("@parDescricao", txtDescricao.Text);
                comando.Parameters.AddWithValue("@parQtdEstoq", txtQtd_Estoq.Text);
                comando.Parameters.AddWithValue("@parEstoqMin", txtEstoq_Min.Text);
                comando.Parameters.AddWithValue("@parUnidade", cmbUnidade.Text);
                comando.Parameters.AddWithValue("@parLocacao", txtLocacao.Text);
                comando.Parameters.AddWithValue("@parPrcCusto", txtPrcCusto.Text);
                comando.Parameters.AddWithValue("@parMargLucro", txtMarg_Lucro.Text);
                conexao.Open();
                comando.ExecuteNonQuery();
            }
            catch (MySqlException Erro)
            {
                MessageBox.Show("ERRO => " + Erro.Message, "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }
            finally
            {
                toolStripStatusMensagem.Text = "Cadastro efetuado com sucesso!!!";
                conexao.Close();
                comando = null;
            }
        }

        private void frmCadProd_Activated(object sender, EventArgs e)
        {
            txtCodigo.Focus();
        }
    }
}
