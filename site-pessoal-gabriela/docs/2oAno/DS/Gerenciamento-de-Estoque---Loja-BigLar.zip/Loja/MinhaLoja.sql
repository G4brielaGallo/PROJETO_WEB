DROP DATABASE IF EXISTS bd_MinhaEmpresa_TA;
CREATE DATABASE bd_MinhaEmpresa_TA;

USE bd_MinhaEmpresa_TA;

CREATE TABLE tb_Login(
usuario_log VARCHAR(20) PRIMARY KEY,
senha_log VARCHAR(8) NOT NULL,
nm_log VARCHAR(30) NOT NULL,
ult_Atualizacao_log TIMESTAMP NOT NULL
);

INSERT INTO tb_Login 
(usuario_log, senha_log, nm_log, ult_Atualizacao_log) VALUES
('GabiGallo','AR$5267','Gabriela Gallo', current_timestamp);

CREATE TABLE tb_Produtos
(
cd_prod varchar(5) primary key,
descricao_prod varchar(30) not null,
qtd_Estoq_prod decimal(5,2) not null,
Estoq_Min_prod decimal(5,2) not null,
unidade_prod char(2) not null,
locacao_prod varchar(3) not null,
PrcCusto_prod decimal(6,2) not null,
Marg_Lucro_prod decimal(4,2) not null,
ult_Atualizacao_prod timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO tb_Produtos VALUES ('123', 'Controle Remoto',0,5.00, 'Pç', 'A01', 150.00, 10.00, current_timestamp );

CREATE TABLE tb_Clientes(
RG_cli VARCHAR(15) PRIMARY KEY,
nm_cli VARCHAR(45) NOT NULL,
endereco_cli VARCHAR(120) NOT NULL,
cidade_cli VARCHAR(30) NOT NULL,
UF_cli CHAR(2) NOT NULL,
tel_cli VARCHAR(13) NOT NULL,
ult_Atualizacao_cli timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- SELECT * FROM tb_Login;
-- SELECT * FROM tb_Produtos;
-- SELECT * FROM tb_Clientes;
-- DELETE FROM tb_Login WHERE usuario_log = "EmillyAntunis";