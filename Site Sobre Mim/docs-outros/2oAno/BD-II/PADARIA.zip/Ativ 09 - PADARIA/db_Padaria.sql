DROP DATABASE IF EXISTS db_Padaria;

CREATE DATABASE db_Padaria;
USE db_Padaria;

CREATE TABLE Categoria(
    cd_categoria int primary key auto_increment,
    nm_categoria varchar(60) not null
);

CREATE TABLE Fornecedores(
    cd_fornecedor int primary key auto_increment,
    nm_fornecedor varchar(80) not null
);

CREATE TABLE Produtos(
    cd_produto int primary key auto_increment,
    nome varchar(75) not null,
    preco decimal(8,2) not null,
    id_categoria int,
    id_fornecedor int,
    foreign key (id_categoria) references Categoria(cd_categoria),
    foreign key (id_fornecedor) references Fornecedores(cd_fornecedor)
);

CREATE TABLE Clientes(
    cd_cliente int primary key auto_increment,
    nm_cliente varchar(80) not null
);

CREATE TABLE Pedidos(
    cd_pedido int primary key auto_increment,
    dt_pedido date not null,
    id_cliente int,
    foreign key (id_cliente) references Clientes(cd_cliente)
);

CREATE TABLE ItensPedido(
    cd_item int primary key auto_increment,
    id_pedido int,
    id_produto int,
    quantidade int,
    foreign key (id_pedido) references Pedidos(cd_pedido),
    foreign key (id_produto) references Produtos(cd_produto)
);

CREATE TABLE AuditoriaVendas(
    cd_item int,
    quantidade int,
    dt_operacao datetime
);

INSERT INTO Categoria(nm_categoria) VALUES
('Pães'),
('Bolos'),
('Bebidas'),
('Salgados');

INSERT INTO Fornecedores(nm_fornecedor) VALUES
('Forno Real'),
('Doces Silva'),
('Bebidas PuraVida'),
('Delícias da Serra');

INSERT INTO Produtos(nome, preco, id_categoria, id_fornecedor) VALUES
('Pão Francês', 0.80, 1, 1),
('Bolo de Cenoura', 12.00, 2, 2),
('Café Pequeno', 4.00, 3, 3),
('Café Grande', 6.00, 3, 3),
('Suco Natural', 7.50, 3, 3),
('Pão de Queijo Grande', 5.00, 4, 4),
('Pão de Queijo Grande', 6.00, 4, 4), 
('Coxinha', 8.50, 4, 4);

INSERT INTO Clientes(nm_cliente) VALUES
('Ana Paula'),
('João Mendes'),
('Carlos Alberto'),
('Lucia Helena'),
('Marcelo Vieira');

INSERT INTO Pedidos(dt_pedido, id_cliente) VALUES
('2025-01-10', 1),
('2025-01-15', 2),
('2025-02-01', 1),
('2025-02-02', 3),
('2025-02-10', 1),
('2025-02-10', 4),
('2025-02-11', 5);

INSERT INTO ItensPedido(id_pedido, id_produto, quantidade) VALUES
(1, 1, 10),
(1, 3, 2),
(2, 5, 3),
(2, 7, 120),
(3, 1, 4),
(3, 4, 1),
(4, 2, 2),
(5, 1, 20),
(5, 8, 2),
(6, 5, 1),
(7, 3, 3),
(7, 4, 2);


UPDATE Produtos SET
    nome = "Pão de Queijo Médio"
WHERE
    cd_produto = 7;

UPDATE Produtos
SET preco = preco * 1.1
WHERE id_categoria = (
    SELECT cd_categoria FROM Categoria WHERE nm_categoria = 'Bebidas'
);

SELECT P.cd_produto, SUM(I.quantidade) AS total_vendido
FROM ItensPedido AS I
INNER JOIN Produtos AS P ON P.cd_produto = I.id_produto
GROUP BY P.cd_produto
ORDER BY total_vendido DESC
LIMIT 5;

SELECT id_cliente, COUNT(*) AS total_pedidos
FROM Pedidos
GROUP BY id_cliente
ORDER BY total_pedidos DESC
LIMIT 3;

SELECT C.nm_cliente, P.nome
FROM Clientes AS C
INNER JOIN Pedidos AS D ON C.cd_cliente = D.id_cliente
INNER JOIN ItensPedido AS I ON D.cd_pedido = I.id_pedido
INNER JOIN Produtos AS P ON P.cd_produto = I.id_produto;

SELECT F.nm_fornecedor, P.nome, I.quantidade
FROM Fornecedores AS F
INNER JOIN Produtos AS P ON F.cd_fornecedor = P.id_fornecedor
INNER JOIN ItensPedido AS I ON P.cd_produto = I.id_produto;

CREATE VIEW ViewVendasRecentes AS
SELECT C.nm_cliente, P.cd_pedido, P.dt_pedido
FROM Clientes AS C
INNER JOIN Pedidos AS P ON C.cd_cliente = P.id_cliente
WHERE P.dt_pedido >= CURDATE() - INTERVAL 30 DAY;

CREATE VIEW ViewProdutosEconomicos AS
SELECT cd_produto, nome, preco
FROM Produtos
WHERE preco < 10.00;

SELECT * FROM ViewProdutosEconomicos;

DELIMITER //
CREATE TRIGGER trg_AuditoriaVendas
AFTER INSERT ON ItensPedido
FOR EACH ROW
BEGIN
    IF NEW.quantidade > 100 THEN
        INSERT INTO AuditoriaVendas VALUES
        (NEW.cd_item, NEW.quantidade, NOW());
    END IF;
END//
DELIMITER ;

DELIMITER //
CREATE TRIGGER trg_ProtegePreco
BEFORE UPDATE ON Produtos
FOR EACH ROW
BEGIN
    IF NEW.preco < (OLD.preco * 0.8) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Reducao de preco maior que 20%';
    END IF;
END//
DELIMITER ;
