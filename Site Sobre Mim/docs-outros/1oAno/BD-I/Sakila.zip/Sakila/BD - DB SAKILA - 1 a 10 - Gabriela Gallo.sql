-- LISTA BD - BANCO DE DADOS SAKILA - 1 A 10 --> GABRIELA GALLO

use sakila;

select * from customer;
select * from store;
select * from film;
select * from inventory;

-- 1) exibir o nome do cliente, id da loja e o endereço da loja onde ele é cadastrado

select
concat(first_name,' ', last_name) as cliente,
lj.store_id as 'id da loja',
ad.address as 'endereço da loja'
from customer as cu
inner join store as lj on lj.store_id = cu.store_id
inner join address as ad on ad.address_id = lj.address_id;

-- 2) exibir o filme e os nomes dos artistas que participaram do filme

select
f.title as "nome do filme",
concat(first_name,' ', last_name) as ator
from film as f
inner join film_actor as fa on fa.film_id = f.film_id
inner join actor as ac on ac.actor_id = fa.actor_id
order by f.title
limit 10000;

-- 3) exibir o filme e a loja onde ele se encontra

select
f.title as "nome do filme",
lj.store_id as "loja"
from film as f
inner join inventory as inv on inv.film_id = f.film_id
inner join store as lj on lj.store_id = inv.store_id
limit 10000;

-- 4) exibir o filme e a quantidade de cópias existentes por título

select
f.title as "nome do filme",
count(inv.film_id) as "quantidade de cópias"
from film as f
inner join inventory as inv on inv.film_id = f.film_id
group by f.title
limit 10000;

-- 5) exibir o filme e a quantidade de cópias existentes por título em cada loja

select
f.title as "nome do filme",
count(inv.film_id) as "quantidade de cópias",
inv.store_id as "loja"
from film as f
inner join inventory as inv on inv.film_id = f.film_id
group by f.title, store_id
limit 10000;

-- 6) exibir o cliente e a quantidade de locações realizadas por cada cliente

select
concat(cus.first_name, ' ', cus.last_name) as cliente,
count(lo.customer_id) as 'quantidade de locações'
from customer as cus
inner join rental as lo on lo.customer_id = cus.customer_id
group by cliente
limit 10000;

-- 7) exibir o filme e a quantidade de vezes que ele foi alugado

select
f.title as 'nome do filme',
count(lo.inventory_id) as 'quantidade de locações'
from film as f
inner join inventory as inv on inv.film_id = f.film_id
inner join rental as lo on lo.inventory_id = inv.inventory_id
group by f.title
limit 10000;

-- 8) exibir o filme e a quantidade de vezes que cada cópia foi alugada

select
f.title as 'nome do filme',
count(lo.inventory_id) as 'quantidade de locações'
from film as f
inner join inventory as inv on inv.film_id = f.film_id
inner join rental as lo on lo.inventory_id = inv.inventory_id
inner join store as lj on inv.store_id = lj.store_id
group by f.title, lo.inventory_id
limit 10000;

-- 9) exibir o cliente e o valor total gasto por cada cliente

select
concat(cus.first_name, ' ', cus.last_name) as cliente,
sum(pa.amount) as 'total gasto'
from customer as cus
inner join payment as pa on pa.customer_id = cus.customer_id
group by cliente
limit 10000;

-- 10) exibir os 10 filmes que mais deram lucro por loja

select
f.title as "nome do filme",
lj.store_id as "loja",
sum(pa.amount) as "lucro"
from
film as f
inner join inventory as inv on inv.film_id = f.film_id
inner join rental as lo on lo.inventory_id = inv.inventory_id
inner join payment as pa on pa.rental_id = lo.rental_id
inner join store as lj on lj.store_id = inv.store_id
group by f.title, lj.store_id
order by sum(pa.amount) desc
limit 10;