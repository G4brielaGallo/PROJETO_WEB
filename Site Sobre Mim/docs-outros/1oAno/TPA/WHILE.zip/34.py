#Questão 34

op=' '

while op != 'M' and op !='F':
    op = str(input('''Digite seu sexo
    F --> Feminino
    M --> Masculino
    
Digite (M/F): ''')).upper()
print('\nFIM')
