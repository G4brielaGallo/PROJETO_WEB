#Questão 40

nmenorf = "n/a"
nmaiorf = "n/a"
nmenorm = "n/a"
nmaiorm = "n/a"
somaf = 0
quantf = 0
somam = 0
quantm = 0
c = 0

while(c==0):
    n = int(input("Insira o salário: "))
    s = str(input('''
    [F] --> Feminino
    [M] --> Masculino
    
    Digite seu sexo(M/F): ''')).upper()
    if(s=="F"):
        if(nmenorf=="n/a" or nmenorf>n):
            nmenorf=n
        if(nmaiorf=="n/a" or nmaiorf<n):
            nmaiorf=n
        quantf+=1
        somaf+=n
    elif(s=="M"):
        if(nmenorm=="n/a" or nmenorm>n):
            nmenorm=n
        if(nmaiorm=="n/a" or nmaiorm<n):
            nmaiorm=n
        quantm+=1
        somam+=n
    else:
        print("Inválido.")
    cont = int(input('''Deseja continuar?
    [1] --> Sim
    [2] --> Não
    
    Digite o número correspondente: '''))
    if(cont==2):
        c=1

mf = somaf/quantf
mm = somam/quantm

print(f"Homens: O menor número foi {nmenorm}\nO maior foi {nmaiorm}\nE a média foi {mm}")
print(f"Mulheres: O menor número foi {nmenorf}\nO maior foi {nmaiorf}\nE a média foi {mf}")