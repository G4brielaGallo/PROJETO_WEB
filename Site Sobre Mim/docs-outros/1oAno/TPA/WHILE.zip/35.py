#Questão 35

ope = 1

while ope <= 5 or ope > 6:
    n1 = float(input('Digite o primeiro número: '))
    n2 = float(input('Digite o segundo número: '))
    ope = int(input('''Escolha a operação: 
    [1] - Soma
    [2] - Multiplicação
    [3] - Subtração
    [4] - Maior e menor
    [5] - Novos números
    [6] - Sair do programa
    
Digite o número correspondente a sua escolha: '''))

    if ope == 1:
        res = n1 + n2
        print(f'O resultado da soma de {n1} por {n2} é {res}.')
    elif ope == 2:
        res = n1 * n2
        print(f' O resultado da multiplição entre {n1} e {n2} é {res}.')
    elif ope == 3:
        res = n1 - n2
        print(f' O resultado da subtração de {n1} por {n2} é {res}.')
    elif ope == 4:
        if n1 > n2:
            print(f'{n1} é maior que {n2}.')
        elif n2 > n1:
            print(f'{n2} é maior que {n1}.')
        else:
            print(f'Ambos os números tem o mesmo valor.')
    else:
        print('Você digitou um número que não condiz com as operações disponíveis, \033[1;31;40mTENTE NOVAMENTE\033[m\n\n')
