#Questão 36

cont = int(input('Digite o número que a ser fatorado: '))
fat = 1

while cont > 0:

    fat = fat * cont
    cont -= 1

print(f"O fatorial é {fat}")

