#Questão 37

q = 0
s = 0
n1 = 1

while n1 != 999:
    n1 = int(input("Digite um número: "))
    q += 1
    s = s + n1
    sres = s - 999
    qres = q-1
print(f'Foram digitados{qres} números e a soma deles é {sres}.')