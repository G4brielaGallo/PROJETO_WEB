#Questão Nº31

maior_kg=0.0
menor_kg=100000000000000000000
maior=0
menor=0

for cont in range (1,11):
    n = int(input('Digite o número do boi: '))
    p = float(input('Digite o peso do boi (em kg): '))

    if p > maior_kg:
        maior_kg = p
        maior = n

    if menor_kg > p:
        menor_kg = p
        menor = n

print(f'O boi mais gordo é o número {maior} pesando {maior_kg}kg e o mais magro é o número {menor} pesando {menor_kg}kg')