#Questão Nº28

print("Programa para calcular Progressão Aritmética(PA)")

pt = int(input("Digite o primeiro termo da PA: "))
r = int(input("Digite a razão da PA:"))

for cont in range(1,11):
    t = pt + cont * r

    print(f"Os dez primeiros termos de sua PA são: {t}")