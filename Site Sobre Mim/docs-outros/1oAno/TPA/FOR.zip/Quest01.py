#Questão Nº22

for cont in range(1,101):
    if cont % 2 == 0:
        print(cont)

print("\n\033[41;30mFim da contagem!\033[m")