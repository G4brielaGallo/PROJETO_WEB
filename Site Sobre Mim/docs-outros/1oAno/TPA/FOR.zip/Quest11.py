#Questão Nº32

op = "Sim"
while op == "Sim":
    n1 = int(input('Digite um número: '))
    nco = 0
    for cont in range(n1, 0, -1):
        if n1 % cont == 0:
            nco += 1

    if nco == 2:
        print(f'{n1} é um número primo')
    else:
        print(f'{n1} Não é um número primo')

    op = str(input('Deseja continuar?\n\033[32mSim\033[m\nou\n\033[31mNão\033[m\n\n'))