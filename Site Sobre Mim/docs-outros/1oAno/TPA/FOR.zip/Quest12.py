#Questão Nº33

mac=0
mic=0
for cont in range (1,8):
    i = int(input(f'Digite a idade da {cont}º pessoa: '))
    if i >= 18:
        mac +=1
    else:
        mic+=1

print(f'Das sete idades digitadas, {mac} pessoas são maiores de idade e {mic} pessoas são menores de idade ')