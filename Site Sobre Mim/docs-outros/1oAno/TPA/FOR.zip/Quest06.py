#Questão N°27

s=0

for cont in range(1,501):
    if cont % 2 == 1:
        s = s + cont

print("A \033[32msoma\033[m de todos os \033[36mnúmeros ímpares\033[m de 1 até 500 é \033[34m{}\033[m".format(s))