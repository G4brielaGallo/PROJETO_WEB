#Questão Nº25

s=0

for cont in range(1,21):
    i = int(input("Digite a idade do indivíduo:"))
    s = s+i

m = s/20

print("A média das idades é {}".format(m))