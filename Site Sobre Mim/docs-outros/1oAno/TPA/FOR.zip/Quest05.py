#Questão Nº26

qf=0
qm=0
qn=0
sf=0
sm=0
sn=0

for cont in range(1,16):
    se = str(input("""\n\nDigite o sexo do funcionário:
    OBS: Digite Feminino ou F para mulheres e Masculino ou M para homens!!!\n"""))
    s = float(input("\nDigite o valor do salário do funcionário:"))
    if se=="Feminino" or se=="F":
        sf = sf+s
        qf = qf+1

    elif se=="Masculino" or se=="M":
        sm = sm+s
        qm = qm+1

    else:
        print("""\n\033[31;40mATENCÃO\033[m
        \nFoi digitado algo diferente das quatro possibilidades de sexo aceitas: Feminino; F; Masculino; M.
        Assim, faremos a média dos salários digitados nas mesmas circunstâncias.""")
        sn = sn+s
        qn = qn+1

mf = sf/qf
mm = sm/qm

print("""\n\nA média dos salários das funcionárias do sexo feminino é {}, sendo em quantidade {} funcionárias.
A média dos salários dos funcionários do sexo masculino é {}, sendo em quantidade {} funcionários.""".format(mf,qf,mm,qm))

if qn!=0:
    mn = sn/qn
    print("A média dos salários dos funcionários de sexo não especificado é {}, sendo em quantidade {} funcionários.".format(mn,qn))