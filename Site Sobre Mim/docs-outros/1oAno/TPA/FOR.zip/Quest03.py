#Questão Nº24

s=0
q=0
ne=0
neu=0

for cont in range(1,51):
    n = float(input("Digite um número: "))
    if n >= 1:
        s = s+cont
        q = q+1
    elif n <= -1:
        ne = ne+1
    else:
        neu = neu+1

if q != 0:
    m = s/q
else:
    m=0

print("""\nA média dos números positivos é {}, sendo em quantidade {} números positivos.
A quantidade de números negativos é {}.
Existem {} números neutros (zeros).""".format(m,q,ne,neu))