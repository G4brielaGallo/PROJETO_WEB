#Questão Nº29

qe = 0
qc = 0
qa = 0

enge2025 = 0
comp2025 = 0
adm2025 = 0

senge = 0
scomp = 0
sadm = 0

for cont in range(1,6):
    cdc = int(input("""\n\nDigite o código do curso do aluno: 
    1 - Engenharia
    2 - Computação
    3 - Administração\n"""))
    id = int(input("\nDigite a idade do aluno: "))

    if cdc == 1:
        qe = (qe+ 1)
        if id >= 20 and id <= 25:
            enge2025 = enge2025 + 1
        senge = senge + id

    elif cdc == 2:
        qc = qc + 1
        if id >= 20 and id <= 25:
            comp2025 = comp2025 + 1
        scomp = scomp + id

    elif cdc == 3:
        qa = qa + 1
        if id >= 20 and id <= 25:
            adm2025 = adm2025 + 1
        sadm = sadm + id

me = senge / qe
mc = scomp / qc
ma = sadm / qa

if me > mc and me > ma:
    m = me
    c = "ENGENHARIA"

elif mc > me and mc > ma:
    m = mc
    c = "COMPUTAÇÃO"

else:
    m = ma
    c = "ADMINISTRAÇÃO"

print("""O NÚMERO DE ALUNOS POR CURSO:
1 - ENGENHARIA: {}       2 - COMPUTAÇÃO: {}      3 - ADMINISTRAÇÃO: {}
----------------------------------------------------------------------
O NÚMERO DE ALUNOS COM IDADES ENTRE 20 E 25 POR CURSO É:
1 - ENGENHARIA: {}       2 - COMPUTAÇÃO: {}      3 - ADMINISTRAÇÃO: {}
----------------------------------------------------------------------
O CURSO COM A MENOR MÉDIA DE IDADES É: CURSO DE {}, COM UMA MÉDIA DE {}""".format(qe, qc, qa, enge2025, comp2025, adm2025, c, m))