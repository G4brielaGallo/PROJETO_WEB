#Questão Nº23

q=0
for cont in range(1,51):
    n = int(input("Digite um número inteiro: "))
    if n % 3 == 0:
        q = q+1

print("O total de números divisíveis por 3 digitados é {}".format(q))