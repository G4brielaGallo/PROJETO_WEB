#Questão Nº30

qp = 0
tsal = 0
imax = 0
imin = 999
mulsal100 = 0

for cont in range(1, 1000000):
    id = int(input("Digite a idade (valor negativo para encerrar): "))
    if id < 0:
        break
    s = str(input("Selecione o seu sexo (M = Masculino/F = Feminino: "))
    sal = float(input("Digite o seu salário: "))

    qp += 1
    tsal += sal

    if imax < id:
        imax = id

    if imin > id:
        imin = id

    if s == 'F' or s == 'Feminino' and sal <= 100:
        mulsal100 += 1

msal = tsal/qp

print(f"""\nMédia de salário do grupo é {msal} reais
Maior idade do grupo é {imax} anos
Menor idade do grupo é {imin} anos
Quantidade de mulheres com salário até R$100,00 é {mulsal100}""")